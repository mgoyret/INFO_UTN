#include "andara.h"
#include "stdio.h"



int main ()
{

	int opcion, mevoy=0, tam=0, valor;
	int * Vector;

	while (!mevoy)
	{
		printf("1. Agregar Dato al final:\n");
		printf("2. Agregar al Principio:\n");
		printf("3. Retirar al Principio:\n");
		printf("4. Retirar al final:\n");
		printf("5. Cambiar un valor:\n");
		printf("6. Buscar un valor:\n");
		printf("7. Mostrar:\n");
		printf("8. Salir:\n");

		scanf("%d", &opcion);

		switch (opcion)
		{
			case 1:
				printf("Que valor desea agregar:");
				scanf("%d", &valor);
				if (agregarDato(&Vector, &tam, valor) == FALSE)
					printf("No se pudo agregar el dato");
				break;
			case 2:
				printf("Que valor desea agregar:");
				scanf("%d", &valor);
				if (agregarPrincipio(&Vector, &tam, valor) <0)
					printf("No se pudo agregar el dato");
				break;
			case 3:
				valor = retirarPrincipio(&Vector, &tam);
				if(valor<0)
					printf("No se pudo quitar el dato");
				else
					printf("Valor: %d, decí alpiste\n", valor);
				break;
			case 4:
				valor = retirarFinal(&Vector, &tam);
				if(valor==1)
					printf("No se pudo quitar el dato");
				break;
			case 5:
				break;
			case 6:
				break;
			case 7:
				mostrar(Vector, tam);
				break;
			case 8:
				mevoy = 1;
				break;
			default: 
				printf("Opción erronea, reintente\n\n");
		}
	}
	return 0;
}

/*
int modificar(int*, int, int, int);
int buscar(int*, int, int);
*/
