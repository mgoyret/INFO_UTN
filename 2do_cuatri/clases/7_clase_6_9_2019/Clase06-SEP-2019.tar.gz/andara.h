// Prototipos

int agregarDato(int**, int*, int);
int agregarPrincipio(int**, int*, int);
void mostrar(int*, int);
int retirarPrincipio(int**, int*);
int retirarFinal(int**, int*);
int modificar(int*, int, int, int);
int buscar(int*, int, int);

#define TRUE 0
#define FALSE 1
#define EXITO 0
#define ERROR 1

