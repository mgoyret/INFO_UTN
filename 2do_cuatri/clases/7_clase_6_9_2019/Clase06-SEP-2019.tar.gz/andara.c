#include <stdio.h>
#include <stdlib.h>
#include "andara.h"


// Funciones :) :)

void mostrar(int* p, int largo)
{
  int i = 0;  
  for (i=0; i < largo; i++)
  {
    printf("Vector[%d] = %d\n",i,*(p+i));
  }
}

int modificar(int *p,int cant ,int pos,int valor)
{
    int retorno;
    
    if(cant>pos)
    {
        p[pos]=valor;
        retorno=EXITO;
    }   
    else
    {
        retorno=ERROR;
    }
    return retorno;
}

int buscar(int *p, int cant, int dato) {
    /* 1. pos vale -1 en caso de que no encuentre la posicion del dato */
    int i, pos = -1;
    /* 2. Ciclo for para averiguar si p[i] es igual al dato pasado por parametro */
    for(i = 0; i < cant; i++) {
        if(*(p+i) == dato) {
            /* 3. El valor i, equivalente a la posicion actual del array pasa a ser el contenido de pos */
            pos = i;
        }
    }
    return pos;
}


int retirarPrincipio(int ** array,int * tam){
    int valor;
    int *vector;
    int i=0;
    vector=*array;
    if(vector!=NULL && *tam!=0){
        valor=vector[0];
        for(i=0; i<*tam-1; i++)
        {
            vector[i]=vector[i+1];
        }
        *tam=*tam-1;
        vector=(int*)realloc(vector,sizeof(int)*(*tam));
        return valor ;
    }
    else
        valor=-1;
    return valor;
}

int agregarPrincipio(int**datos,int*size,int dato){
    int validation;
    int i = (*size) + 1,j = 0;

  	// Si es la primera vez que se usa -> malloc
    if((*size)==0){
        *datos = (int*)malloc(((*size)+1)*sizeof(int));

        if(*datos){
            **datos = dato;
            validation = 0;
            *size = (*size) + 1;
        }else{
            printf("ERROR al asignar memoria.\n");
            validation = -1;
        }
    }else{ // Si ya se usó -> realloc
        *datos = (int*)realloc(*datos,i*sizeof(int));

        if(*datos){ // Compruebo si se asignó correctamente la memoria
            for(j=*size;j>0;j--){ // Muevo todos los datos un lugar...
                *(*datos+j) = *(*datos+j-1); 
            } *(*datos) = dato;// ...y agrego el nuevo

            validation = 0;
            *size = (*size) + 1;
        }else{
            printf("ERROR al asignar memoria.\n");
            validation = -1;
        }
    }

    return validation;
}

int retirarFinal(int **vector,int *largo)
{
    int res=0;
  //Disminuyo el largo en 1
    *largo-=1;
  //realizo el realloc con el tamaño disminuido
    *vector=(int*)realloc(*vector,sizeof(int)*(*largo));
  //verifico que no haya funcionado el realloc
    if (vector==NULL)
    {
        printf("ERROR al realizar el realloc");
        free(*vector);
        res=-1;
    }
return res;   
}

int agregarDato(int **vec,int*tam,int valor)
{
	int *aux,aux2,status;
	if(*tam==0)
	{
		*vec=(int*)malloc(1*sizeof(int));
		if(*vec!=NULL)
		{
			**vec=valor;
			status=TRUE;
			(*tam)++;
		}
		else
		{
			printf("No hay memoria\n");
			status= FALSE;
		}
	}
	else
	{
		aux2=*tam+1;
		aux=(int*)realloc(*vec,aux2*sizeof(int));
		if(aux!=NULL)
		{
			*(aux+(*tam))=valor;
			*vec=aux;
			status= TRUE;
			(*tam)++;
		}
		else
		{
			printf("No hay memoria disponible\n");
			status=FALSE;
		}
	}
	return status;
}

