# Fiducials.pretty

Fiducial and location markers
