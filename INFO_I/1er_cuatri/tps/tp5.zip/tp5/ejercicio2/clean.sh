#!/bin/bash

# Para ejecutar: 
# Opcion 1) bash clean.sh
# Opcion 2) chmod +x clean.sh
#           ./clean.sh

rm -r -f *.o
rm -f program