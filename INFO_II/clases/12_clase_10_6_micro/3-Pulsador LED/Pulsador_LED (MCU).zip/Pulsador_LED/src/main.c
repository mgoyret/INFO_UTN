/**
*	\file main.c
*	\brief Resumen del contenido del archivo
*	\details Descripcion detallada del archivo
*	\author Federico_Bua
*	\date 31-03-2019 17:38:41
*/

#include "funciones.h"



int main()
{
	inicializar();

	while(1)
	{
		maquina_estado();
	}
	return 0;
}
