#include "funciones.h"
void SysTick_Handler (void)
{
	DriverTeclado();
	BarridoDisplay();
}
