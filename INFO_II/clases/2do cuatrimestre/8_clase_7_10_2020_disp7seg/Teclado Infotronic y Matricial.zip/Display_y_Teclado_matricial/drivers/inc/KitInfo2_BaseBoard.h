//Identificación de los puertos de expansion:


	#define 	PORT0			0
	#define 	PORT1			1
	#define 	PORT2			2
	#define 	PORT3			3
	#define 	PORT4			4

	//Prototipos de función:


	#define EXPANSION0		PORT2,7
	#define EXPANSION1		PORT1,29
	#define EXPANSION2		PORT4,28
	#define EXPANSION3		PORT1,23
	#define EXPANSION4		PORT1,20
	#define EXPANSION5		PORT0,19
	#define EXPANSION6		PORT3,26
	#define EXPANSION7		PORT1,25
	#define EXPANSION8		PORT1,22
	#define EXPANSION9		PORT1,19
	#define EXPANSION10		PORT0,20
	#define EXPANSION11		PORT3,25
	#define EXPANSION12		PORT1,27
	#define EXPANSION13		PORT1,24
	#define EXPANSION14		PORT1,21
	#define EXPANSION15		PORT1,18
	#define EXPANSION16		PORT1,31
	#define EXPANSION17		PORT0,24
	#define EXPANSION18		PORT0,25
	#define EXPANSION19		PORT0,17
	#define EXPANSION20		PORT1,31
	#define EXPANSION21		PORT0,22
	#define EXPANSION22		PORT0,15
	#define EXPANSION23		PORT0,16
	#define EXPANSION24		PORT2,8
	#define EXPANSION25		PORT2,12
	#define EXPANSION26		PORT1,31
	#define EXPANSION27		PORT1,31

